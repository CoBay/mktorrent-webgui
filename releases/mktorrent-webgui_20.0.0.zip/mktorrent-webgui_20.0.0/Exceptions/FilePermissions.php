<?php


namespace CoBay\mktorrent_webgui\Exceptions;


class FilePermissions extends Exception {
	
}