# mktorrent-webgui
------
A PHP Based WebGUI for [mktorrent](https://github.com/Rudde/mktorrent).
